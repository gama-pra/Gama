<!-- NAVBAR -->
<nav class="navbar" style="background-color: #ffffff; box-shadow: none;">
	<div class="logo">
		<a href="<?= site_url(); ?>" style="color: #4C85BD;">Cerpen</a>
	</div>
	<div class="menu-item" style="display: none;">
		<a href="#" class="item">Beranda</a>
		<a href="#" class="item">Baca Cerpen</a>
		<a href="#" class="item">Nulis Cerpen</a>
		<a href="#" class="item">Tentang Kami</a>
		<a href="<?= site_url('auth'); ?>" class="btnMasuk active">Masuk</a>
	</div>
</nav>

<section class="authPage">
	<div class="formAuth">
		
		<h3 class="judulAuth">Masuk dulu dong.</h3>
		<?= $this->session->flashdata('pesan');  ?>
		<?= form_open('auth/prosesMasuk'); ?>
			<input type="email" name="email" class="inputAuth" placeholder="Masukkan email anda" autofocus autocomplete="off" value="<?= set_value('email'); ?>">  <small style="color: red;"><?= form_error('email'); ?></small>
			<input type="password" name="password" class="inputAuth" placeholder="Masukkan password anda" autocomplete="off">  <small style="color: red;"><?= form_error('password'); ?></small>
			<input type="submit" value="Masuk" class="inputAuth btnInputSubmit">
			<div class="pilihanAuth">
				<div class="pilih">Belum punya akun? <a href="<?= site_url('auth/daftar'); ?>">Daftar disini</a>.</div>
			</div>
		<?= form_close(); ?>

	</div>
</section>