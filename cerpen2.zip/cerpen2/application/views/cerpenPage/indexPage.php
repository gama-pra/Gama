<!-- NAVBAR -->
<nav class="navbar">
	<div class="logo">
		<a href="<?= site_url(); ?>">Cerpen</a>
	</div>
	<div class="menu-item">
		<a href="#" class="item">Beranda</a>
		<a href="#" class="item">Baca Cerpen</a>
		<a href="#" class="item">Nulis Cerpen</a>
		<a href="#" class="item">Tentang Kami</a>
		<a href="<?= site_url('auth'); ?>" class="btnMasuk">Masuk</a>
	</div>
</nav>

<!-- JUMBOTRON -->
<section class="jumbotron">
	<div class="container">
		<div class="text-center">
			
			<div class="text-jumbotron">
				<h1>Ayo Mulai Membaca!</h1>
				<p>Lebih dari 2.000 judul yang bisa kamu baca disini.</p>
			</div>

		</div>
	</div>
</section>

<!-- CERPEN -->
<section class="cerpen" id="bacaCerpen">
	<div class="container">
		
		<div class="menu-cerpen">
			<div class="kategori">
				<a href="#" class="semua">Semua</a>
				<a href="#" class="seram active">Seram</a>
				<a href="#" class="romantis">Romantis</a>
				<a href="#" class="persahabatan">Persahabatan</a>
				<a href="#" class="lucu">Lucu</a>
			</div>
			<div class="search">
				<div class="cover-search">
					<input type="text" placeholder="cari judul...">
					<button type="submit" value="">
		        <i class="fa fa-search"></i>
		     </button>
	     </div>
			</div>
		</div>

		<div class="list-cerpen">

			<a href="" class="card" style="
			 background: url(<?= base_url('assets/img/cerpen1.jpg'); ?>);
			 background-repeat: no-repeat;
			 background-size: cover;
			 background-position: center;
			">
				<h1 class="judul">KEJADIAN DI GEDUNG SEKOLAH</h1>
				<span class="ditulis">
					ditulis oleh <br>
					<span class="name">Muhammad Azrial</span>
				</span>
			</a>

			<a href="" class="card" style="
			 background: url(<?= base_url('assets/img/cerpen2.jpg'); ?>);
			 background-repeat: no-repeat;
			 background-size: cover;
			 background-position: center;
			">
				<h1 class="judul">LORONG PANJANG RUMAH SAKIT SURABAYA</h1>
				<span class="ditulis">
					ditulis oleh <br>
					<span class="name">Gama Pra Bintang</span>
				</span>
			</a>

			<a href="" class="card" style="
			 background: url(<?= base_url('assets/img/cerpen3.jpg'); ?>);
			 background-repeat: no-repeat;
			 background-size: cover;
			 background-position: center;
			">
				<h1 class="judul">TEMPAT TIDUR KECILKU</h1>
				<span class="ditulis">
					ditulis oleh <br>
					<span class="name">Albert Einstein</span>
				</span>
			</a>

			<a href="" class="card" style="
			 background: url(<?= base_url('assets/img/cerpen3.jpg'); ?>);
			 background-repeat: no-repeat;
			 background-size: cover;
			 background-position: center;
			">
				<h1 class="judul">TEMPAT TIDUR KECILKU</h1>
				<span class="ditulis">
					ditulis oleh <br>
					<span class="name">Albert Einstein</span>
				</span>
			</a>

			<a href="" class="card" style="
			 background: url(<?= base_url('assets/img/cerpen2.jpg'); ?>);
			 background-repeat: no-repeat;
			 background-size: cover;
			 background-position: center;
			">
				<h1 class="judul">LORONG PANJANG RUMAH SAKIT SURABAYA</h1>
				<span class="ditulis">
					ditulis oleh <br>
					<span class="name">Gama Pra Bintang</span>
				</span>
			</a>

			<a href="" class="card" style="
			 background: url(<?= base_url('assets/img/cerpen1.jpg'); ?>);
			 background-repeat: no-repeat;
			 background-size: cover;
			 background-position: center;
			">
				<h1 class="judul">KEJADIAN DI GEDUNG SEKOLAH</h1>
				<span class="ditulis">
					ditulis oleh <br>
					<span class="name">Muhammad Azrial</span>
				</span>
			</a>

		</div>

		<div class="btnBS">
			<a href="#">Tampilkan Lagi</a>
		</div>

	</div>
</section>

<!-- TENTANG -->
<section class="tentang">
	<div class="container">
		
		<div class="rowTentang">
			<div class="col-gambarTentang">
				<img src="<?= base_url('assets/img/gambarTentang.svg'); ?>" alt="Gambar Tentang" class="gambarTentang">
			</div>
			<div class="col-textTentang">
				<h1>Tentang Cerpen</h1>
				<p>
					Cerpen adalah sebuah Lorem ipsum dolor sit amet, consectetur adipisicing elit. Exercitationem, optio? Dolor non odio veritatis impedit neque est eius cumque, pariatur atque id fuga porro totam blanditiis reprehenderit repellendus corporis optio.
				</p>
				<a href="" class="btnBacaTentang">Baca Selengkapnya</a>
			</div>
		</div>

	</div>
</section>