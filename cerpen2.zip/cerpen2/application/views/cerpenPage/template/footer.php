	<!-- FOOTER -->
	<footer>
		<div class="container">
			Cerpen 2019 | Dibuat dengan
			<i class="fa fa-heart"></i> dan
			<i class="fa fa-coffee"></i>
		</div>
	</footer>

</body>
</html>