	<!-- NAVBAR -->
	<nav class="navbar" style="background-color: #ffffff; box-shadow: none;">
		<div class="logo">
			<a href="<?= site_url(); ?>" style="color: #4C85BD;">Cerpen</a>
		</div>
		<div class="menu-item" style="display: none;">
			<a href="#" class="item">Beranda</a>
			<a href="#" class="item">Baca Cerpen</a>
			<a href="#" class="item">Nulis Cerpen</a>
			<a href="#" class="item">Tentang Kami</a>
			<a href="<?= site_url('auth'); ?>" class="btnMasuk active">Masuk</a>
		</div>
	</nav>

	<section class="loginPage">
		<div class="formLogin">
			
			<h3 class="judulLogin">Masuk dulu dong.</h3>
			<form action="#" method="POST">
				<input type="email" name="email" class="inputLogin" placeholder="Masukkan email anda" autofocus>
				<input type="password" name="password" class="inputLogin" placeholder="Masukkan password anda">
				<input type="submit" value="Masuk" class="inputLogin btnInputMasuk">
				<div class="daftardisini">
					<div class="daftar">Belum punya akun? <a href="#">Daftar disini</a>.</div>
				</div>
			</form>

		</div>
	</section>