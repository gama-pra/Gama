<?php

	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class Cerpen extends CI_Controller {

		public function __construct()
		{
			parent::__construct();
			$this->load->helper('url');
		}
	
		public function index()
		{
			$data['judul'] = "Cerpen - Tempat Membaca dan Menulis Cerpen";

			$this->load->view('cerpenPage/template/header', $data);
			$this->load->view('cerpenPage/indexPage');
			$this->load->view('cerpenPage/template/footer');
		}
	
	}
	
	/* End of file Cerpen.php */
	/* Location: ./application/controllers/Cerpen.php */

?>