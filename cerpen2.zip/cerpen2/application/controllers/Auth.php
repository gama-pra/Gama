<?php

	defined('BASEPATH') OR exit('No direct script access allowed');
	
	class Auth extends CI_Controller {


		public function __construct()
		{
			parent::__construct();
			$this->load->helper(array('form', 'url'));
			$this->load->library('form_validation');
			$this->load->library(array('PHPMailer_lib'));
		}
	
		public function index()
		{
			redirect('auth/masuk');
		}

		public function masuk()
		{
			$data['judul'] = "Masuk | Cerpen - Tempat Membaca dan Menulis Cerpen";

			$this->load->view('cerpenPage/template/header', $data);
			$this->load->view('cerpenPage/masukPage');
			$this->load->view('cerpenPage/template/footer');
		}

		public function daftar()
		{
			$data['judul'] = "Daftar | Cerpen - Tempat Membaca dan Menulis Cerpen";

			$this->load->view('cerpenPage/template/header', $data);
			$this->load->view('cerpenPage/daftarPage');
			$this->load->view('cerpenPage/template/footer');
		}

		public function keluar()
		{
			session_destroy();
			redirect('');
		}

		















		public function prosesMasuk()
		{
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
			$this->form_validation->set_rules('password', 'Password', 'trim|required');

				if ($this->form_validation->run() == false) {
			$data['judul'] = "Daftar | Cerpen - Tempat Membaca dan Menulis Cerpen";

			$this->load->view('cerpenPage/template/header', $data);
			$this->load->view('cerpenPage/masukPage');
			$this->load->view('cerpenPage/template/footer');
			} else {

				$email = $this->input->post('email');
				$password = $this->input->post('password');

				$user = $this->db->get_where('user', ['email' => $email])->row_array();


				// jika user ada
				if ($user) {
					if ($user['is_active'] == 1) {
						// cek password

						if (password_verify($password, $user['password'])) {
							redirect(site_url());
						} else {
							$this->session->set_flashdata('pesan', 'Password Salah ');
							redirect('auth/masuk');
						}


					} else {
						$this->session->set_flashdata('pesan', 'Email belum di aktivasi');
						redirect('auth/masuk');
					}

				} else {
					$this->session->set_flashdata('pesan', 'Email belum terdaftar');
					redirect('auth/masuk');
				}


			}
		}



















		public function prosesDaftar()
		{
			$this->form_validation->set_rules('nama', 'Name', 'required|trim');
			$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[user.email]',[
					'is_unique' => 'Email sudah terdaftar'
			]);
			$this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[8]',[
					'min_length' => 'Password too short'
			]);

			if ($this->form_validation->run() == false) {
			$data['judul'] = "Daftar | Cerpen - Tempat Membaca dan Menulis Cerpen";

			$this->load->view('cerpenPage/template/header', $data);
			$this->load->view('cerpenPage/daftarPage');
			$this->load->view('cerpenPage/template/footer');

		    } else {
		    	
		    	$data =[
		    		'nama' => htmlspecialchars($this->input->post('nama', true)),
		    		'email' => htmlspecialchars($this->input->post('email', true)),
		    		'foto' => 'default.jgp',
		    		'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
		    		'is_active' => 0,
		    		'data_created' => time()
		    	];

		    	$token = base64_encode(random_bytes(16));
		    	$user_token = [

		    		'email' => $this->input->post('email', true),
		    		'token' => $token,
		    		'data_created' => time()
		    	];

		    	$this->db->insert('user', $data);
		    	$this->db->insert('user_token', $user_token);
		    	$this->_sendEmail($token, 'verify');
		    	$this->session->set_flashdata('pesan', 'Akun berhasil di buat! Silahkan Aktifasi');
		    	redirect('auth/masuk');		    
		    }	
		}

		public function verify(){

		$email = $this->input->get('email');
		$token = $this->input->get('email');

		$user = $this->db->get_where('user', ['email' => $email])->row_array();

		if ($user) {
			
			$user_token = $this->db->get_where('user_token', ['token' => $token])->row_array();

			if ($user_token) {
				
				if (time() - $user_token['data_created'] < (60*60*24)) {
					
					$this->db->set('is_active', 1);
					$this->db->where('email', $email);
					$this->db->update('user');

					$this->db->delete('$user_token', ['email' => $email]);

					$this->session->set_flashdata('pesan',  ' Email telah di aktifasi! silahkan login');
					redirect('auth');

				} else {

					$this->db->delete('user', ['email' => $email]);
					$this->db->delete('user_token', ['email' => $email]);

					$this->session->set_flashdata('pesan', 'Aktifasi Gagal! Token kadaluwarsa');
					redirect('auth');
				}

			} else {
				$this->session->set_flashdata('pesan', 'Aktifasi Gagal! Token Salah');
			}

		} else {
			$this->session->set_flashdata('pesan', 'Aktifasi Gagal! Email Salah');
			redirect('auth');
		}
		}
	

		private function _sendEmail($token, $type)
		{
					$config = [
						'protocol'  => 'smtp',
						'smtp_host' => 'ssl://smtp.googlemail.com',
						'smtp_user' => 'gamaxrpl1@gmail.com',
						'smtp_pass' => 'gama123qwert',
						'smtp_port' =>  465,
						'mailtype'  => 'html',
						'charset'   => 'utf-8',
						'starttls'  => true,
						'newline'   => "\r\n"
					];
					
					$this->load->library('email', $config);
					$this->email->initialize($config);
					$this->email->from('gamaxrpl1@gmail.com', 'Gama pra Bintang');
					$this->email->to($this->input->post('email'));
				
			if ( $type == 'verify') {
				$this->email->subject('Akfivasi Akun ');
				$this->email->message('Klik untuk aktivasi <a href="' . base_url() . 'auth/verify?email=' . $this->input->post('email') . '$token=' . urlencode($token) . '">aktivasi</a>');
			}
			if($this->email->send()){
				return true;
			} else {
				echo $this->email->print_debugger();
				die;
			}
		}

	
	

	
}













	/* End of file Auth.php */
	/* Location: ./application/controllers/Auth.php */

?>